def main():
    print("Hello from mountain-recoder!")


if __name__ == "__main__":
    main()
