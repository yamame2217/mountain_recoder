from django.contrib import admin
from .models import Mountain, ClimbRecord  

# Register your models here.
admin.site.register(Mountain)      
admin.site.register(ClimbRecord)   